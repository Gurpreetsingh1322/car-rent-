import "./Loading.css";

const Loding = () => {
  return (
    <div className="container-loading">
      <div class="centered-content">
        <div className="loding">
          <div className="custom-loader"></div>
        </div>
      </div>
    </div>
  );
};

export default Loding;
